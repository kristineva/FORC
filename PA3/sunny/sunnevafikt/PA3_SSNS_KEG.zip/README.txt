# FORC_PA3
Project by: Sunneva Sól N Sigurðardóttir    sunneva18@ru.is
            Kristín Eva Gísladóttir         kristing18@ru.is


We solved version A.
To compile and run the program in the terminal:
    "g++ -o encoder *.cpp -std=c++11"
    "./encoder -d [encodedFile.txt] [fileToStoreDecodedVersion.txt]"         <-- if you wish to decode a file
    "./encoder -e [decodedFile.txt] [fileToStoreEncodedVersion.txt]"         <-- if you wish to encode a file
Note that any filenames work.